package model.zombie;

import model.zombie.zombies.ArmorDecorator;
import model.zombie.zombies.NormalZombie;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public final class ZombieFactory {

    private static final List<String> BASIC_ZOMBIE_TYPES = Arrays.asList("normal", "conehead", "buckethead");
    private static final Random RANDOM = new Random();

    private ZombieFactory() {}

    public static Zombie create(String type) {
        switch (type.toLowerCase()) {
            case "normal":
                return new NormalZombie();
            case "conehead":
                // یک زامبی نرمال می‌سازیم، یک کلاه ۳۷۰تایی می‌ذاریم سرش
                return new ArmorDecorator(new NormalZombie(), "cone", 370, 150);
            case "buckethead":
                // یک زامبی نرمال می‌سازیم، یک سطل ۱۱۰۰تایی می‌ذاریم سرش
                return new ArmorDecorator(new NormalZombie(), "bucket", 1100, 200);
            default:
                throw new IllegalArgumentException("زامبی ناشناخته: " + type);
        }
    }

    public static Zombie randomBasicZombie() {
        String type = BASIC_ZOMBIE_TYPES.get(RANDOM.nextInt(BASIC_ZOMBIE_TYPES.size()));
        return create(type);
    }
}