package model.zombie.zombies;

import model.game.GameSession;
import model.zombie.Zombie;
import model.zombie.ZombieFactory;

public class BarrelRollerZombie extends Zombie {

    private int barrelHealth = 400; // جان دبه
    private boolean barrelBroken = false;

    public BarrelRollerZombie() {
        super("barrelroller", 250, 0.015, 200, 10);
    }

    @Override
    public void takeDamage(int amount, GameSession session) {


        if (!barrelBroken && barrelHealth > 0) {
            barrelHealth -= amount;
            if (barrelHealth <= 0) {
                breakBarrelAndSpawnImps(session);

                super.takeDamage(-barrelHealth);
            }
        } else {
            super.takeDamage(amount);
        }
    }

    private void breakBarrelAndSpawnImps(GameSession session) {
        barrelBroken = true;


        Zombie imp1 = ZombieFactory.create("imp");
        Zombie imp2 = ZombieFactory.create("imp");


        imp1.spawn(getRow(), getXPosition() - 0.2);
        imp2.spawn(getRow(), getXPosition() + 0.2);

        session.getAliveZombies().add(imp1);
        session.getAliveZombies().add(imp2);



    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;
        setXPosition(getXPosition() - getSpeed());

    }
}