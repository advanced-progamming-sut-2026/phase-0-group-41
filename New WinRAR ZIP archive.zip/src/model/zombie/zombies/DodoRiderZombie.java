package model.zombie.zombies;

import model.game.GameSession;
import model.game.Tile;
import model.plant.Plant;
import model.zombie.Zombie;

public class DodoRiderZombie extends Zombie {

    public DodoRiderZombie() {
        super("dodorider", 350, 0.02, 175, 10);
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        Plant target = findPlantInFront(session);

        if (target != null) {
            handleObstacle(target);
        } else {
            // حرکت عادی
            setXPosition(getXPosition() - getSpeed());
            setEating(false);
        }
    }

    private Plant findPlantInFront(GameSession session) {
        int col = (int) Math.floor(getXPosition());
        if (col >= 0 && col < 9) {
            Tile tile = session.getBoard().getTile(getRow(), col);
            return (tile != null) ? tile.getPlant() : null;
        }
        return null;
    }

    private void handleObstacle(Plant target) {
        if (target.getName().equalsIgnoreCase("tallnut")) {
            target.takeDamage(getDamagePerTick());
            setEating(true);
        } else {
            setXPosition(getXPosition() - getSpeed());
            setEating(false);
        }
    }
}