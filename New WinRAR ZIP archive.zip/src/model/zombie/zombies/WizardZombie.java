package model.zombie.zombies;

import model.game.Board;
import model.game.GameSession;
import model.game.Tile;
import model.plant.Plant;
import model.zombie.Zombie;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WizardZombie extends Zombie {

    private static final int SPELL_COOLDOWN_TICKS = 30; // هر ۳ ثانیه
    private int ticksSinceLastSpell = 0;
    private final List<Plant> sheepedPlants = new ArrayList<>();
    private final Random random = new Random();

    public WizardZombie() {
        super("wizard", 300, 0.01, 250, 0); // دمیج صفر چون به گربه/گوسفند تبدیل می‌کند و نمی‌خورد
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        ticksSinceLastSpell++;
        if (ticksSinceLastSpell >= SPELL_COOLDOWN_TICKS) {
            castSheepSpell(session);
            ticksSinceLastSpell = 0;
        }

        // حرکت همیشگی (چون گیاهی نمی‌خورد، فقط راه می‌رود)
        setXPosition(getXPosition() - getSpeed());
    }

    private void castSheepSpell(GameSession session) {
        Board board = session.getBoard();
        List<Plant> activePlants = new ArrayList<>();

        // پیدا کردن همه گیاهانی که هنوز طلسم نشده‌اند
        for (int r = 0; r < Board.ROWS; r++) {
            for (int c = 0; c < Board.COLS; c++) {
                Tile tile = board.getTile(r, c);
                Plant p = (tile != null) ? tile.getPlant() : null;
                // فرض می‌کنیم در کلاس Plant متد isSheep() اضافه کرده‌اید
                if (p != null && !p.isDead() && !p.isSheep()) {
                    activePlants.add(p);
                }
            }
        }

        if (!activePlants.isEmpty()) {
            Plant target = activePlants.get(random.nextInt(activePlants.size()));
            target.setSheep(true);
            sheepedPlants.add(target);
        }
    }

    @Override
    public void takeDamage(int amount) {
        super.takeDamage(amount);
        if (isDead()) {
            restorePlants();
        }
    }

    private void restorePlants() {
        for (Plant plant : sheepedPlants) {
            if (!plant.isDead()) {
                plant.setSheep(false); // باطل شدن طلسم
            }
        }
        sheepedPlants.clear();
    }
}