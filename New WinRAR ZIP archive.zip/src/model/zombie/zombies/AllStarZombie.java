package model.zombie.zombies;

import model.game.GameSession;
import model.game.Tile;
import model.plant.Plant;
import model.zombie.Zombie;

public class AllStarZombie extends Zombie {

    private boolean isCharging = true;
    private static final double CHARGE_SPEED = 0.05;
    private static final double WALK_SPEED = 0.01;

    public AllStarZombie() {
        super("allstar", 600, CHARGE_SPEED, 250, 10);
    }

    @Override
    public double getSpeed() {
        return isCharging ? CHARGE_SPEED : WALK_SPEED;
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        Plant target = findTarget(session);
        if (target != null) {
            handleCollision(target);
        } else {
            setXPosition(getXPosition() - getSpeed());
        }
    }

    private Plant findTarget(GameSession session) {
        int col = (int) Math.floor(getXPosition());
        Tile tile = session.getBoard().getTile(getRow(), col);
        return (tile != null) ? tile.getPlant() : null;
    }

    private void handleCollision(Plant target) {
        if (isCharging) {
            target.takeDamage(9999);
            isCharging = false;
        } else {
            target.takeDamage(getDamagePerTick());
        }
    }
}