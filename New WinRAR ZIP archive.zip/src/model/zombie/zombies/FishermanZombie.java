package model.zombie.zombies;

import model.game.Board;
import model.game.GameSession;
import model.game.Tile;
import model.plant.Plant;
import model.zombie.Zombie;

public class FishermanZombie extends Zombie {

    private static final int HOOK_COOLDOWN_TICKS = 50; // هر ۵ ثانیه قلاب می‌اندازه
    private int ticksSinceLastHook = 0;

    public FishermanZombie() {
        // سرعت صفر است چون حرکت نمی‌کنه
        super("fisherman", 350, 0.0, 100, 0);
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        ticksSinceLastHook++;
        if (ticksSinceLastHook >= HOOK_COOLDOWN_TICKS) {
            castHook(session);
            ticksSinceLastHook = 0; // ریست کردن تایمر
        }
    }

    private void castHook(GameSession session) {
        Board board = session.getBoard();
        // پیدا کردن اولین گیاه در سطر خودش از راست به چپ
        for (int col = Board.COLS - 1; col >= 0; col--) {
            Tile tile = board.getTile(getRow(), col);
            if (tile != null && tile.getPlant() != null) {
                pullOrDestroyPlant(board, tile, col);
                break; // فقط یک گیاه را می‌کشد
            }
        }
    }

    private void pullOrDestroyPlant(Board board, Tile currentTile, int col) {
        Plant targetPlant = currentTile.getPlant();

        // اگر گیاه چسبیده به ماهیگیر است (ستون ۸)، آن را به بیرون پرتاب و نابود می‌کند
        if (col == Board.COLS - 1) {
            targetPlant.takeDamage(9999);
            currentTile.setPlant(null);
            return;
        }

        // کشیدن گیاه به یک خانه جلوتر (سمت راست) اگر خالی باشد
        Tile nextTile = board.getTile(getRow(), col + 1);
        if (nextTile != null && nextTile.isEmpty()) {
            currentTile.setPlant(null);
            targetPlant.place(getRow(), col + 1);
            nextTile.setPlant(targetPlant);
        }
    }
}