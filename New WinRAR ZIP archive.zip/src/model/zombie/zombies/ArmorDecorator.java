package model.zombie.zombies;

import model.game.GameSession;
import model.zombie.Zombie;

public class ArmorDecorator extends Zombie {

    private final Zombie wrappedZombie;
    private final String armorName;
    private int armorHealth;

    public ArmorDecorator(Zombie wrappedZombie, String armorName, int armorHealth, int waveCost) {

        super(wrappedZombie.getTypeName(), wrappedZombie.getHealth(), wrappedZombie.getSpeed(), waveCost, wrappedZombie.getDamagePerTick());
        this.wrappedZombie = wrappedZombie;
        this.armorName = armorName;
        this.armorHealth = armorHealth;
    }

    @Override
    public void spawn(int row, double xPosition) {
        wrappedZombie.spawn(row, xPosition);
    }

    @Override
    public void onTick(GameSession session) {
        wrappedZombie.onTick(session);
    }


    @Override
    public void takeDamage(int amount) {
        if (armorHealth > 0) {
            armorHealth -= amount;
            if (armorHealth < 0) {

                wrappedZombie.takeDamage(-armorHealth);
                armorHealth = 0;
            }
        } else {
            wrappedZombie.takeDamage(amount);
        }
    }


    @Override
    public boolean isDead() { return wrappedZombie.isDead(); }

    @Override
    public double getXPosition() { return wrappedZombie.getXPosition(); }

    @Override
    public int getRow() { return wrappedZombie.getRow(); }

    @Override
    public int getHealth() { return wrappedZombie.getHealth(); }


    public String getArmorName() { return armorName; }
    public int getArmorHealth() { return armorHealth; }
}