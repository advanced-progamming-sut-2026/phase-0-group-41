package model.zombie.zombies;

import model.game.GameSession;
import model.game.TerrainType;
import model.game.Tile;
import model.plant.Plant;
import model.zombie.Zombie;

public class SnorkelZombie extends Zombie {

    private boolean submerged = false;

    public SnorkelZombie() {
        super("snorkel", 200, 0.015, 125, 10);
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        Plant target = findTarget(session);
        Tile currentTile = getCurrentTile(session);

        if (target != null) {
            // وقتی به گیاه می‌رسد برای خوردن، به سطح آب می‌آید
            submerged = false;
            target.takeDamage(getDamagePerTick());
            setEating(true);
        } else {
            // حرکت می‌کند؛ اگر خانه آب بود، زیر آب می‌رود
            setXPosition(getXPosition() - getSpeed());
            setEating(false);
            submerged = (currentTile != null && currentTile.getTerrainType() == TerrainType.WATER);
        }
    }

    public boolean isSubmerged() {
        return submerged;
    }

    private Tile getCurrentTile(GameSession session) {
        int col = (int) Math.floor(getXPosition());
        return session.getBoard().getTile(getRow(), col);
    }

    private Plant findTarget(GameSession session) {
        Tile tile = getCurrentTile(session);
        return (tile != null) ? tile.getPlant() : null;
    }
}