package model.zombie.zombies;

import model.game.GameSession;
import model.zombie.Zombie;

import java.util.List;

public class KingZombie extends Zombie {

    private static final int KNIGHTING_COOLDOWN = 60; // مثلا هر ۶ ثانیه
    private int ticksSinceLastKnighting = 0;

    public KingZombie() {
        // سرعت صف ، هزینه موج بالا
        super("king", 400, 0.0, 300, 0);
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        ticksSinceLastKnighting++;
        if (ticksSinceLastKnighting >= KNIGHTING_COOLDOWN) {
            crownAZombie(session);
            ticksSinceLastKnighting = 0;
        }
    }

    private void crownAZombie(GameSession session) {
        List<Zombie> zombies = session.getAliveZombies();

        for (int i = 0; i < zombies.size(); i++) {
            Zombie z = zombies.get(i);

            // پیدا کردن یک زامبی معمولی که تو همون سطرِ پادشاه باشه
            if (z.getTypeName().equalsIgnoreCase("normal") && z.getRow() == this.getRow()) {

                // تبدیل زامبی معمولی به شوالیه با دکوراتور
                // ۸۰۰ جان برای کلاه‌خود (طبق داک)
                Zombie knight = new ArmorDecorator(z, "knight_helm", 800, 100);

                // جایگزین کردن زامبی معمولی با شوالیه در لیست
                zombies.set(i, knight);
                break; // در هر بار فقط یک نفر را شوالیه می‌کند
            }
        }
    }
}