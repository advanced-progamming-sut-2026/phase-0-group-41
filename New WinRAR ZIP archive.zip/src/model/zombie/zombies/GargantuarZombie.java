package model.zombie.zombies;

import model.game.GameSession;
import model.plant.Plant;
import model.zombie.Zombie;
import model.zombie.ZombieFactory;

public class GargantuarZombie extends Zombie {

    private static final double SPEED = 0.005; // سرعت بسیار کم
    private final int initialHealth;
    private boolean impThrown = false;

    public GargantuarZombie() {

        super("gargantuar", 3000, SPEED, 300, 9999);
        this.initialHealth = 3000;
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        checkAndThrowImp(session);

        Plant target = findPlantInFront(session);
        if (target != null) {
            crushPlant(target);
        } else {
            move();
        }
    }

    // متد کوچک ۱: بررسی وضعیت پرتاب Imp
    private void checkAndThrowImp(GameSession session) {
        if (!impThrown && getHealth() <= initialHealth / 2) {
            impThrown = true;
            Zombie imp = ZombieFactory.create("imp");
            // پرتاب به ستون سوم (اندیس ۲) در همان سطر
            imp.spawn(getRow(), 2.0);
            session.getAliveZombies().add(imp);
        }
    }

    // متد کوچک ۲: هدف‌یابی
    private Plant findPlantInFront(GameSession session) {
        int col = (int) Math.floor(getXPosition());
        if (col >= 0 && col < 9) {
            return session.getBoard().getTile(getRow(), col).getPlant();
        }
        return null;
    }

    // متد کوچک ۳: له کردن
    private void crushPlant(Plant target) {
        setEating(true);
        target.takeDamage(getDamagePerTick()); // چون دمیج ۹۹۹۹ است، گیاه درجا می‌میرد
    }

    // متد کوچک ۴: حرکت
    private void move() {
        setEating(false);
        setXPosition(getXPosition() - SPEED);
    }
}