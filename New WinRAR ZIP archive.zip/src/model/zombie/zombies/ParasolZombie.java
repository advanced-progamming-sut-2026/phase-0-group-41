package model.zombie.zombies;

import model.game.GameSession;
import model.zombie.Zombie;

public class ParasolZombie extends Zombie {

    public ParasolZombie() {
        super("parasol", 350, 0.01, 150, 10);
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;
        setXPosition(getXPosition() - getSpeed());
        // (منطق خوردن مشابه زامبی‌های عادی)
    }


    public void receiveLobbedProjectile(int damage) {
        System.out.println("Parasol Zombie deflected the lobbed attack!");

    }


    @Override
    public void takeDamage(int amount) {
        super.takeDamage(amount);
    }
}