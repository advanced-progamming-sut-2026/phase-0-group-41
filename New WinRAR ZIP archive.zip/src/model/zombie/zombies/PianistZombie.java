package model.zombie.zombies;

import model.game.Board;
import model.game.GameSession;
import model.zombie.Zombie;

import java.util.List;
import java.util.Random;

public class PianistZombie extends Zombie {

    private static final int DANCE_COOLDOWN_TICKS = 40; // مثلا هر ۴ ثانیه
    private int ticksSinceLastDance = 0;
    private final Random random = new Random();

    public PianistZombie() {
        super("pianist", 400, 0.005, 250, 10); // سرعت بسیار کم
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        ticksSinceLastDance++;
        if (ticksSinceLastDance >= DANCE_COOLDOWN_TICKS) {
            makeZombiesDance(session);
            ticksSinceLastDance = 0;
        }

        // حرکت عادی به جلو
        setXPosition(getXPosition() - getSpeed());
    }

    private void makeZombiesDance(GameSession session) {
        List<Zombie> aliveZombies = session.getAliveZombies();

        for (Zombie z : aliveZombies) {

            if (z != this && random.nextBoolean()) {
                changeZombieLane(z);
            }
        }
    }

    private void changeZombieLane(Zombie zombie) {
        int currentRow = zombie.getRow();
        boolean canGoUp = currentRow > 0;
        boolean canGoDown = currentRow < Board.ROWS - 1;

        if (canGoUp && canGoDown) {
            zombie.spawn(random.nextBoolean() ? currentRow - 1 : currentRow + 1, zombie.getXPosition());
        } else if (canGoUp) {
            zombie.spawn(currentRow - 1, zombie.getXPosition());
        } else if (canGoDown) {
            zombie.spawn(currentRow + 1, zombie.getXPosition());
        }
    }
}