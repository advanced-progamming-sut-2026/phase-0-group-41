package model.zombie.zombies;

import model.game.Board;
import model.game.GameSession;
import model.game.Tile;
import model.plant.Plant;
import model.zombie.Zombie;

public class JesterZombie extends Zombie {

    private boolean isSpinning = false;
    private int spinTicksRemaining = 0;
    private static final double WALK_SPEED = 0.015;
    private static final double SPIN_SPEED = 0.03; // حین چرخش سریع‌تر می‌رود

    public JesterZombie() {
        super("jester", 350, WALK_SPEED, 200, 10);
    }

    @Override
    public double getSpeed() {
        return isSpinning ? SPIN_SPEED : WALK_SPEED;
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        updateSpinState();

        Plant target = findTarget(session);
        if (target != null && !isSpinning) {
            // اگر نمی‌چرخد، عادی می‌خورد
            target.takeDamage(getDamagePerTick());
            setEating(true);
        } else {
            // حرکت به جلو
            setXPosition(getXPosition() - getSpeed());
            setEating(false);
        }
    }

    private void updateSpinState() {
        if (spinTicksRemaining > 0) {
            spinTicksRemaining--;
            if (spinTicksRemaining == 0) {
                isSpinning = false;
            }
        }
    }

    private Plant findTarget(GameSession session) {
        int col = (int) Math.floor(getXPosition());
        Tile tile = session.getBoard().getTile(getRow(), col);
        return (tile != null) ? tile.getPlant() : null;
    }

    /**
     * گیاهان پرتاب‌گر (مثل Peashooter) به جای takeDamage باید این متد را صدا بزنند.
     */
    public void receiveProjectile(GameSession session, int damage, boolean isFrozen) {
        if (!isSpinning) {
            // شروع به چرخیدن می‌کند (مثلاً برای ۲۰ تیک)
            isSpinning = true;
            spinTicksRemaining = 20;
        }

        // اگر در حال چرخش است، دمیج نمی‌خورد، بلکه تیر را برمی‌گرداند
        reflectProjectile(session, damage, isFrozen);
    }

    private void reflectProjectile(GameSession session, int damage, boolean isFrozen) {
        Board board = session.getBoard();
        int currentCol = (int) Math.floor(getXPosition());

        // پیدا کردن اولین گیاه در سمت چپ زامبی برای برخورد تیرِ برگشتی
        for (int col = currentCol; col >= 0; col--) {
            Tile tile = board.getTile(getRow(), col);
            if (tile != null && tile.getPlant() != null) {
                Plant hitPlant = tile.getPlant();
                hitPlant.takeDamage(damage);

                // اگر تیر یخی بود، گیاه یخ می‌زند (فرض بر وجود متد freeze در Plant)
                if (isFrozen) {
                    // hitPlant.freeze(); // این متد باید در کلاس Plant اضافه شود
                }
                break; // تیر به اولین گیاه می‌خورد و متوقف می‌شود
            }
        }
    }
}