package model.zombie.zombies;

import model.game.GameSession;
import model.game.Tile;
import model.plant.Plant;
import model.zombie.Zombie;

public class TurquoiseZombie extends Zombie {

    private int stolenSuns = 0;
    private int ticksAlive = 0;
    private static final int STEAL_INTERVAL = 10; // هر ثانیه (۱۰ تیک)
    private static final int LASER_INTERVAL = 50; // هر ۵ ثانیه (۵۰ تیک)

    public TurquoiseZombie() {
        super("turquoise", 400, 0.01, 300, 10);
    }

    @Override
    public void onTick(GameSession session) {
        if (isDead()) return;

        ticksAlive++;

        if (ticksAlive % STEAL_INTERVAL == 0) {
            stealSun(session);
        }

        if (ticksAlive % LASER_INTERVAL == 0) {
            shootLaser(session);
        }

        moveOrAttack(session); // حرکت عادی
    }

    private void stealSun(GameSession session) {
        // اگر بازیکن خورشید داشت، ۲۵ تا بدزد
        if (session.getSunManager().spendSun(25)) {
            stolenSuns += 25;
        }
    }

    private void shootLaser(GameSession session) {
        int currentCol = (int) Math.floor(getXPosition());
        // نابود کردن گیاهان تا ۴ خانه جلوتر (سمت چپ زامبی)
        for (int i = 1; i <= 4; i++) {
            int targetCol = currentCol - i;
            if (targetCol >= 0) {
                Tile tile = session.getBoard().getTile(getRow(), targetCol);
                if (tile != null && tile.getPlant() != null) {
                    tile.getPlant().takeDamage(9999); // نابودی با لیزر
                }
            }
        }
    }

    @Override
    public void takeDamage(int amount) {
        super.takeDamage(amount);
        // وقتی مرد، نصف خورشیدهای دزدیده شده را به صورت FallingSun روی زمین می‌اندازد
        // (این بخش نیاز به تعامل با کلاس SunManager دارد)
        if (isDead()) {
            // منطق برگرداندن خورشید به سیستم
        }
    }

    private void moveOrAttack(GameSession session) {
        // مشابه قبرساز (حذف برای جلوگیری از طولانی شدن کد)
    }
}